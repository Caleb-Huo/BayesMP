# BayesMP
R package for Bayes Meta Pattern


## Required Package
* not declared yet

## Install This Package
First you need R `devtools` package installed.
* In command line:
```
R -e "devtools::install_github(\"xiaoguang1988/BayesMP\")"
```
* In R console
```R
library(devtools)
install_github("xiaoguang1988/BayesMP")
```

## release note:
0.0.0 only contain BayesMP mcmc function.