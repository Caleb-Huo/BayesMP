# BayesMP
R package for Bayes Meta Pattern
