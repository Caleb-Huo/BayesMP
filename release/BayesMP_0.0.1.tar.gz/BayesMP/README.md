# BayesMP
R package for Bayes Meta Pattern


## Required Package
* not declared yet

## Install This Package
First downlowd the R package "https://github.com/xiaoguang1988/BayesMP/blob/master/release/BayesMP_0.0.0.tar.gz"
* In command line:
```
R CMD INSTALL BayesMP_0.0.0.tar.gz
```
* In R console
```R
install.packages("BayesMP_0.0.0.tar.gz", repos = NULL, type="source")
```

## release note:
0.0.0 only contain BayesMP mcmc function.